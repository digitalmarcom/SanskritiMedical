/* Sanskriti Santosh Medical College — Shared JS */

// ── Tabs ──
function initTabs(){
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function(){
      const target = this.dataset.target;
      const group = this.closest('.tab-group') || document;
      group.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      group.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      this.classList.add('active');
      document.getElementById(target)?.classList.add('active');
    });
  });
}

// ── Accordion ──
function initAccordion(){
  document.querySelectorAll('.accordion-header').forEach(h => {
    h.addEventListener('click', function(){
      const body = this.nextElementSibling;
      const isOpen = this.classList.contains('open');
      // close all in same accordion group
      const group = this.closest('.accordion-group') || document;
      group.querySelectorAll('.accordion-header').forEach(x => { x.classList.remove('open'); x.nextElementSibling.classList.remove('open'); });
      if(!isOpen){ this.classList.add('open'); body.classList.add('open'); }
    });
  });
}

// ── Dept tabs ──
function showDeptTab(id){
  document.querySelectorAll('.dept-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-'+id)?.classList.add('active');
}

// ── Scroll effects ──
function initScroll(){
  const btt = document.querySelector('.back-to-top-btn');
  window.addEventListener('scroll', () => {
    btt?.classList.toggle('show', window.scrollY > 400);
  });
  btt?.addEventListener('click', e => { e.preventDefault(); window.scrollTo({top:0,behavior:'smooth'}); });
}

// ── Sidebar active on scroll ──
function initSidebarHighlight(){
  const links = document.querySelectorAll('.sidebar-links a[href^="#"]');
  if(!links.length) return;
  window.addEventListener('scroll', () => {
    let fromTop = window.scrollY + 140;
    links.forEach(link => {
      const section = document.querySelector(link.hash);
      if(!section) return;
      if(section.offsetTop <= fromTop && section.offsetTop + section.offsetHeight > fromTop){
        links.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      }
    });
  });
}

// ── Counter Animation ──
function animateCounter(el, target, dur){
  let start = 0;
  const step = target / (dur / 16);
  const t = setInterval(() => {
    start = Math.min(start + step, target);
    el.textContent = Math.floor(start);
    if(start >= target) clearInterval(t);
  }, 16);
}
function initCounters(){
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if(e.isIntersecting){
        e.target.querySelectorAll('[data-count]').forEach(el => {
          animateCounter(el, parseInt(el.dataset.count), 1500);
        });
        obs.unobserve(e.target);
      }
    });
  },{threshold:.3});
  document.querySelectorAll('.count-section').forEach(s => obs.observe(s));
}

// ── Form validation ──
function initForm(){
  document.querySelectorAll('form.validate').forEach(form => {
    form.addEventListener('submit', function(e){
      e.preventDefault();
      let valid = true;
      this.querySelectorAll('[required]').forEach(field => {
        if(!field.value.trim()){
          field.style.borderColor = '#e0181e';
          valid = false;
        } else {
          field.style.borderColor = '';
        }
      });
      if(valid){
        const btn = this.querySelector('button[type=submit]');
        if(btn){ btn.textContent = 'Submitted! We will contact you soon.'; btn.disabled = true; }
      }
    });
  });
}

// ── Notice ticker duplicate for seamless loop ──
function initTicker(){
  const track = document.querySelector('.notice-track');
  if(track){
    const clone = track.innerHTML;
    track.innerHTML = clone + clone;
  }
}

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initAccordion();
  initScroll();
  initSidebarHighlight();
  initCounters();
  initForm();
});
